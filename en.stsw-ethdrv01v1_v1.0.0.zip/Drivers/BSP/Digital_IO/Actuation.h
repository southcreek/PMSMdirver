#define LOW     0x00
#define HIGH    0x01
#define FAULT   0x02
#define GOOD    0x03
#define OFF     0x04
#define ON      0x05

#define IPS_DIAG1_Pin                GPIO_PIN_15
#define IPS_DIAG1_PORT               GPIOC
#define IPS_DIAG2_Pin                GPIO_PIN_14
#define IPS_DIAG2_PORT               GPIOC


#define IPS_CH1_Pin GPIO_PIN_11
#define IPS_CH1_GPIO_Port GPIOC
#define IPS_CH2_Pin GPIO_PIN_12
#define IPS_CH2_GPIO_Port GPIOC


#define CLT_CH1_Pin GPIO_PIN_0
#define CLT_CH1_GPIO_Port GPIOD
#define CLT_CH2_Pin GPIO_PIN_1
#define CLT_CH2_GPIO_Port GPIOD






// function 
void GPIO_Actuation_Init (void);
void CLT03_2Q3_Read(void);
void IPS160H_Actuate(void);
void Update_Actuation_ERT (void);
void Read_DIAG_IPS (void);
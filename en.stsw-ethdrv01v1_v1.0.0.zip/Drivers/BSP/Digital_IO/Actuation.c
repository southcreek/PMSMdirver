/**
******************************************************************************
* @file           : Actuation.c
* @brief          : BSP routines to handle CLT03-2Q3 and IPS160H devices
******************************************************************************
* @attention
*
* <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
* All rights reserved.</center></h2>
*
* This software component is licensed by ST under Ultimate Liberty license
* SLA0044, the "License"; You may not use this file except in compliance with
* the License. You may obtain a copy of the License at:
*                             www.st.com/SLA0044
*
******************************************************************************
*/

#include "stm32f7xx_hal.h"
#include "stm32f7xx_nucleo_144.h"
#include "stm32f7xx_hal_gpio.h"
#include "stm32f7xx_hal_usart.h"
#include "Actuation.h"
#include "App_DemoApplication.h"
#include "RS485.h"
uint8_t Channel1_level=0;  //CLT03-2Q3 input state HIGH/LOW
uint8_t Channel2_level=0;  //CLT03-2Q3 input state HIGH/LOW
uint8_t tx_buff[4];
uint8_t rx_buff[4];
uint8_t ch1_value=0; //CLT03-2Q3 input value 
uint8_t ch2_value=0; //CLT03-2Q3 input value 
uint8_t rx_flag=0;
uint8_t buff[4];
extern uint16_t rx_TimeToInit;


extern uint8_t out1; //IPS160H output value 
extern uint8_t out2; //IPS160H output value 
extern uint8_t out1_status;  //IPS160H status FAULT/GOOD
extern uint8_t out2_status;  //IPS160H status FAULT/GOOD
extern APP_PROCESS_DATA_OUTPUT_T txValue;
extern USART_HandleTypeDef UartHandle;


/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */

void GPIO_Actuation_Init (void)
{
   GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, IPS_CH1_Pin|IPS_CH2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : IPS_CH1_Pin IPS_CH2_Pin */
  GPIO_InitStruct.Pin = IPS_CH1_Pin|IPS_CH2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : CLT_CH1_Pin CLT_CH2_Pin */
  GPIO_InitStruct.Pin = CLT_CH1_Pin|CLT_CH2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
  
  /*Configure GPIO pins : PC15 PC14 */
  GPIO_InitStruct.Pin = IPS_DIAG1_Pin|IPS_DIAG2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
  
  /* NVIC setting for IPS diagnostic detection*/

//  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
//  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
  
}

/**
  * @brief  IPS160H Diagnoctic detection with GPIOs Read
  * @retval int
  */

void Read_DIAG_IPS (void)
{

  if(HAL_GPIO_ReadPin(GPIOC,IPS_DIAG1_Pin)==GPIO_PIN_SET)
  {
      if(out1==ON)
      {
        out1_status=GOOD;
      } 
  }
  else if(HAL_GPIO_ReadPin(GPIOC,IPS_DIAG1_Pin)==GPIO_PIN_RESET)
  {
      if(out1==ON)
      {
        out1_status=FAULT;
      }    
  }
 
  if(HAL_GPIO_ReadPin(GPIOC,IPS_DIAG2_Pin)==GPIO_PIN_SET)
  {
     if(out2==ON)
      {
        out2_status=GOOD;
      }    
  }
  else if(HAL_GPIO_ReadPin(GPIOC,IPS_DIAG2_Pin)==GPIO_PIN_RESET)
  {
      if(out2==ON)
      {
        out2_status=FAULT;
      }     
  }

}



/**
  * @brief CLT03-2Q3 Read channel
  * @param None
  * @retval None
  */
void CLT03_2Q3_Read(void)
{  
  

  Read_DIAG_IPS();
  
  if(HAL_GPIO_ReadPin(CLT_CH1_GPIO_Port,CLT_CH1_Pin)==1)
  {
    
    ch1_value=0x01;

    Channel1_level=HIGH;
    
  }
  
  if(HAL_GPIO_ReadPin(CLT_CH2_GPIO_Port,CLT_CH2_Pin)==1)
  {
    
    ch2_value=0x10;
        
    Channel2_level=HIGH;
    
  } 
  
  if(HAL_GPIO_ReadPin(CLT_CH1_GPIO_Port,CLT_CH1_Pin)==0)
  {
    ch1_value=0x0E;    
    Channel1_level=LOW;
  }
  if(HAL_GPIO_ReadPin(CLT_CH2_GPIO_Port,CLT_CH2_Pin)==0)
  {
    ch2_value=0xE0;
    Channel2_level=LOW;
  }
  
   tx_buff[0]=ch1_value | ch2_value;
 
  if(rx_flag==0)
  {
    RS485_Transmission(tx_buff[0]);  
    rx_flag=1;
  }
  if(rx_TimeToInit>20000)
  {
     RS485_Init();
     HAL_GPIO_WritePin(RS485_EN_PORT,RS485_EN_PIN,GPIO_PIN_SET);
     rx_TimeToInit=0;
     rx_flag=0;
  }
  else if(rx_flag==2)
  {
      IPS160H_Actuate();
  }
  
  Update_Actuation_ERT();
}

/**
  * @brief IPS160H Drive, channel map: CH1 is first four bit, CH2 is second fourth bit
  * @param None
  * @retval None
  */

void IPS160H_Actuate(void)
{
  
  if((rx_buff[0]==49)&(rx_buff[2]==48))
  {
    HAL_GPIO_WritePin(IPS_CH1_GPIO_Port,IPS_CH1_Pin,GPIO_PIN_SET);
    HAL_GPIO_WritePin(IPS_CH2_GPIO_Port,IPS_CH2_Pin,GPIO_PIN_RESET);
    out1=ON;
    out2=OFF;
    out2_status=GOOD;
  }
  else if((rx_buff[0]==48)&(rx_buff[2]==49))
  {
    HAL_GPIO_WritePin(IPS_CH1_GPIO_Port,IPS_CH1_Pin,GPIO_PIN_RESET);
    HAL_GPIO_WritePin(IPS_CH2_GPIO_Port,IPS_CH2_Pin,GPIO_PIN_SET);
    out1=OFF;
    out2=ON;
    out1_status=GOOD;
  }
  
  else if((rx_buff[0]==48)&(rx_buff[2]==48))
  {
    HAL_GPIO_WritePin(IPS_CH1_GPIO_Port,IPS_CH1_Pin,GPIO_PIN_RESET);
    HAL_GPIO_WritePin(IPS_CH2_GPIO_Port,IPS_CH2_Pin,GPIO_PIN_RESET);
    out1=OFF;
    out2=OFF;
    out1_status=GOOD;
    out2_status=GOOD;
  }
         
   else if((rx_buff[0]==49)&(rx_buff[2]==49))
  {
    HAL_GPIO_WritePin(IPS_CH1_GPIO_Port,IPS_CH1_Pin,GPIO_PIN_SET);
    HAL_GPIO_WritePin(IPS_CH2_GPIO_Port,IPS_CH2_Pin,GPIO_PIN_SET);
    out1=ON;
    out2=ON;
  }
  HAL_GPIO_WritePin(RS485_EN_PORT,RS485_EN_PIN,GPIO_PIN_SET); 
  tx_buff[0]=out1;
  tx_buff[1]=out2;
  tx_buff[2]=out1_status;
  tx_buff[3]=out2_status;
  
  memset(rx_buff,0,sizeof(rx_buff));
  rx_flag=0;

}


  
void Update_Actuation_ERT (void)
{
  txValue.actuation_CH1run= out1;
  txValue.actuation_CH2run= out2;
  txValue.actuation_CH1status= out1_status;
  txValue.actuation_CH2status= out2_status;

}

/**************************************************************************************
Exclusion of Liability for this demo software:
  The following software is intended for and must only be used for reference and in an
  evaluation laboratory environment. It is provided without charge and is subject to
  alterations. There is no warranty for the software, to the extent permitted by
  applicable law. Except when otherwise stated in writing the copyright holders and/or
  other parties provide the software "as is" without warranty of any kind, either
  expressed or implied.
  Please refer to the Agreement in README_DISCLAIMER.txt, provided together with this file!
  By installing or otherwise using the software, you accept the terms of this Agreement.
  If you do not agree to the terms of this Agreement, then do not install or use the
  Software!
**************************************************************************************/

/**************************************************************************************

Copyright (c) Hilscher Gesellschaft fuer Systemautomation mbH. All Rights Reserved.

***************************************************************************************/

#include "AppECS_DemoApplication.h"
#include "App_DemoApplication.h"
#include "App_PacketCommunication.h"
#include "App_SystemPackets.h"
#include "hostAbstractionLayer.h"
#include "Hil_ApplicationCmd.h"
#include "Hil_SystemCmd.h"
#include "Hil_Results.h"
#include "Hil_Packet.h"
#include "Hil_DualPortMemory.h"
#include "App_EventHandler.h"
#include "Ecs_Public.h"

/***************************************************************************************/

#define STR(tok) #tok

static struct
{
  char* szCommandName;
  uint32_t ulCommandCode;
} s_atCommandNameLookupTable[] =
{
  /* Protocol stack independent packets */
  { STR(HIL_CHANNEL_INIT_REQ), HIL_CHANNEL_INIT_REQ },
  { STR(HIL_CHANNEL_INIT_CNF), HIL_CHANNEL_INIT_CNF },

  { STR(HIL_REGISTER_APP_REQ), HIL_REGISTER_APP_REQ },
  { STR(HIL_REGISTER_APP_CNF), HIL_REGISTER_APP_CNF },

  { STR(HIL_UNREGISTER_APP_REQ), HIL_UNREGISTER_APP_REQ },
  { STR(HIL_UNREGISTER_APP_CNF), HIL_UNREGISTER_APP_CNF },

  { STR(HIL_START_STOP_COMM_REQ), HIL_START_STOP_COMM_REQ },
  { STR(HIL_START_STOP_COMM_CNF), HIL_START_STOP_COMM_CNF },

  { STR(HIL_LINK_STATUS_CHANGE_IND), HIL_LINK_STATUS_CHANGE_IND },
  { STR(HIL_LINK_STATUS_CHANGE_RES), HIL_LINK_STATUS_CHANGE_RES },

  { STR(HIL_SET_REMANENT_DATA_REQ), HIL_SET_REMANENT_DATA_REQ },
  { STR(HIL_SET_REMANENT_DATA_CNF), HIL_SET_REMANENT_DATA_CNF },

  { STR(HIL_FIRMWARE_IDENTIFY_REQ), HIL_FIRMWARE_IDENTIFY_REQ},
  { STR(HIL_FIRMWARE_IDENTIFY_CNF), HIL_FIRMWARE_IDENTIFY_CNF},

  /* Protocol stack specific packets */
  { STR(ECAT_SET_CONFIG_REQ), ECAT_SET_CONFIG_REQ},
  { STR(ECAT_SET_CONFIG_CNF), ECAT_SET_CONFIG_CNF},

  { STR(ECAT_ESM_ALSTATUS_CHANGED_IND), ECAT_ESM_ALSTATUS_CHANGED_IND},
  { STR(ECAT_ESM_ALSTATUS_CHANGED_RES), ECAT_ESM_ALSTATUS_CHANGED_RES},

  /* PNS as an example, they has to be changes to ECS specific ones */
//  { STR(  PNS_IF_SET_CONFIGURATION_REQ), PNS_IF_SET_CONFIGURATION_REQ },
//  { STR(  PNS_IF_SET_CONFIGURATION_CNF), PNS_IF_SET_CONFIGURATION_CNF },
//
//  { STR(  PNS_IF_PARAM_END_IND), PNS_IF_PARAM_END_IND },
//  { STR(  PNS_IF_PARAM_END_RES), PNS_IF_PARAM_END_RES },




  /* This always must be the last entry in this table */
  { "Unknown command", 0xffffffff },
};

/*******************************************************************************/

extern char* LookupCommandCode(uint32_t ulCmd)
{
  int i;
  for (i = 0; i < sizeof(s_atCommandNameLookupTable) / sizeof(s_atCommandNameLookupTable[0]); i++)
  {
    if (s_atCommandNameLookupTable[i].ulCommandCode == ulCmd)
    {
      return s_atCommandNameLookupTable[i].szCommandName;
    }
  }

  /* Comamnd not in lookup table: Return last entry of table */
  return s_atCommandNameLookupTable[i - 1].szCommandName;
}

/*******************************************************************************/



int32_t Protocol_StartConfiguration( APP_DATA_T* ptAppData )
{
  int32_t ulRet = CIFX_NO_ERROR;

  /* Register handler for indication packets. */
  if( Pkt_RegisterIndicationHandler( AppECS_PacketHandler, (void*)ptAppData ) )
  {
    #ifdef HOST_APPLICATION_SETS_MAC_ADDRESS
      uint8_t abMacAddr[6] = { 0x00, 0x02, 0xA2, 0x2F, 0x90, 0x58 };

      Sys_AssembleSetMacAddressReq( &ptAppData->tPacket, &abMacAddr[0] );
      ulRet = Pkt_SendReceivePacket( ptAppData->hChannel, &ptAppData->tPacket );
      if( ulRet != CIFX_NO_ERROR )
        return ulRet;
    #endif

#ifdef HOST_APPLICATION_STORES_REMANENT_DATA
    /* Set non-volatile BLOB */
    ulRet = AppECS_SetRemanentData( ptAppData );
    if( ulRet != CIFX_NO_ERROR )
      return ulRet;
#endif

    /* Download the configuration */
        ulRet = AppECS_ConfigureStack( ptAppData );
  }
  else
  {
    ulRet = CIFX_DRV_INIT_ERROR;
  }

  return ulRet;
}

/*******************************************************************/

int32_t Protocol_PacketHandler( APP_DATA_T* ptAppData )
{
  int32_t ulRet = CIFX_NO_ERROR;

  ulRet = Pkt_CheckReceiveMailbox( ptAppData->hChannel, &ptAppData->tPacket );

  if( CIFX_DEV_GET_NO_PACKET == ulRet || CIFX_DEV_NOT_READY == ulRet )
  {
    /* Handle "no packet" and "stack not ready" as success. */
    ulRet = CIFX_NO_ERROR;
  }

  return ulRet;
}

/*****************************************************************************/
/*! Protocol special event handler
*   \param ptAppData   pointer to APP_DATA_T structure
*   \param eEvent      event type                                            */
/*****************************************************************************/
void Protocol_EventHandler( APP_DATA_T* ptAppData,
                            APP_EVENT_E eEvent,
                            uint32_t    ulEventData )
{
  switch(eEvent)
  {
    case APP_EVENT_SET_ALARM1:
      break;
    case APP_EVENT_CLEAR_ALARM1:
      break;

    case APP_EVENT_SET_ALARM2:
      break;
    case APP_EVENT_CLEAR_ALARM2:
      break;

    case APP_EVENT_SET_ALARM3:
      break;
    case APP_EVENT_CLEAR_ALARM3:
      break;

    case APP_EVENT_SET_ALARM4:
      break;
    case APP_EVENT_CLEAR_ALARM4:
      break;

    case APP_EVENT_SET_ERROR1:
      break;
    case APP_EVENT_CLEAR_ERROR1:
      break;

    case APP_EVENT_SET_ERROR2:
      break;
    case APP_EVENT_CLEAR_ERROR2:
      break;

    case APP_EVENT_SET_ERROR3:
      break;
    case APP_EVENT_CLEAR_ERROR3:
      break;

    case APP_EVENT_SET_ERROR4:
      break;
    case APP_EVENT_CLEAR_ERROR4:
      break;

    default:
      break;
  }
}


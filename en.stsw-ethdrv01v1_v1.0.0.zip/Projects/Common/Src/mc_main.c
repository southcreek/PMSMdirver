/**
******************************************************************************
* @file           : mc_main.c
* @brief          : motor control mainc source file
******************************************************************************
* @attention
*
* <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
* All rights reserved.</center></h2>
*
* This software component is licensed by ST under Ultimate Liberty license
* SLA0044, the "License"; You may not use this file except in compliance with
* the License. You may obtain a copy of the License at:
*                             www.st.com/SLA0044
*
******************************************************************************
*/



#include "mc_main.h"
#include "motorcontrol.h"
#include "App_DemoApplication.h"
#include "PositionDemo.h"
#include "main.h"
#include "Actuation.h"

extern MCT_Handle_t MCT[NBR_OF_MOTORS];
extern DAC_UI_Handle_t * pDAC;
uint16_t vbusMeas,tempMeas;
uint16_t test = 0;

volatile MC_Protocol_REG_t dacCH0 = MC_PROTOCOL_REG_MEAS_ROT_SPEED;
volatile MC_Protocol_REG_t dacCH1 = MC_PROTOCOL_REG_I_Q_REF;
MC_Protocol_REG_t dacCH0_ = MC_PROTOCOL_REG_I_A, dacCH1_ = MC_PROTOCOL_REG_I_B;

volatile int16_t targetRPM = 3000;
int16_t targetRPM_;

volatile uint16_t rampDuration;
int16_t measSpeedRPM;
volatile uint32_t waitTimems = 5000;

extern APP_PROCESS_DATA_INPUT_T  rxValue;
extern APP_PROCESS_DATA_OUTPUT_T txValue;

typedef enum {
  SLAVE_IDLE,
  SLAVE_RECEIVING
} slaveState_t;

slaveState_t slaveState = SLAVE_IDLE;
volatile uint16_t slaveTest = 0;
float fSlaveTestTargetPos = 0.0f;
volatile float fSlaveTestAcceleration = 0.01f;
uint32_t cycleController = 0;
uint16_t startAlign = 0;

void main_mc_loop(void)
{
  while (1)
  {
    // Slave logic
    cycleController++;
    CLT03_2Q3_Read();

    switch (slaveState) {
      case SLAVE_IDLE:
      {
        if (rxValue.start == 1) {
          // Read data
          uint8_t commandID = rxValue.commandID;
          switch (commandID) {
          case CMD_STARTALIGN:
            {
              MC_StartMotor1();
              txValue.status = 0;
              startAlign = 1;
            }
            break;
          case CMD_ENCALIGN:
            {
              MC_AlignEncoderMotor1();
              txValue.status = 0;
            }
            break;
          case CMD_GETSTATUS:
            {
              txValue.status = SLAVE_STATUS_READY;
              
              if ((MC_GetAlignmentStatusMotor1()== TC_ALIGNMENT_COMPLETED) && 
                  (MC_GetSTMStateMotor1() == RUN) &&
                  (startAlign == 1))
              {
                txValue.status = SLAVE_STATUS_ALIGNED;
                startAlign = 2;
              } else if (startAlign == 2) {
                if (MC_GetControlPositionStatusMotor1() == TC_READY_FOR_COMMAND) {
                  txValue.status = SLAVE_STATUS_POSITIONED;
                }
              }
              
              if (MC_GetControlPositionStatusMotor1() == TC_MOVEMENT_ON_GOING) {
                txValue.status = SLAVE_STATUS_READY;
              }
              
              if ((MC_GetSTMStateMotor1() == FAULT_NOW) || (MC_GetSTMStateMotor1() == FAULT_OVER)) {
                txValue.status = SLAVE_STATUS_FAULT;
              }
            }
            break;
          case CMD_SETPOSITION:
            {
              float fTargetPos = rxValue.position;
              float fDuration = rxValue.duration;
              MC_ProgramPositionCommandMotor1(fTargetPos, fDuration);
              txValue.status = SLAVE_STATUS_READY;
            }
            break;
          case CMD_CLEAR_FAULT:
            {
              MC_AcknowledgeFaultMotor1();
              txValue.status = 0;
            }
            break;
          case CMD_STOP_MOTOR:
            {
              MC_StopMotor1();
              txValue.status = 0;
            }
            break;
          case CMD_RESET:
            {
              NVIC_SystemReset();
            }
            break;
          default:
            {
              txValue.status = SLAVE_STATUS_ERROR;
            }
            break;
          }
          
          txValue.done = DONE_BIT;
          slaveState = SLAVE_RECEIVING;
        }
      }
      break;
      
      case SLAVE_RECEIVING:
      {
        if (rxValue.start == 0) {
          txValue.done = 0;
          slaveState = SLAVE_IDLE;
        }
      }
      break;
    }
    
    switch (slaveTest) {
    case 1:
      {
        MC_StartMotor1();
        slaveTest = 0;
      }
      break;
    case 2:
      {
        MC_StopMotor1();
        slaveTest = 0;
      }
      break;  
    case 3:
      {
        float fDuration = 0.0f;
        MC_ProgramPositionCommandMotor1(fSlaveTestTargetPos, fDuration);
        fSlaveTestTargetPos += fSlaveTestAcceleration;
        HAL_Delay(5);
      }
      break;
    case 4:
      {
        float fDuration = 0.0f;
        MC_ProgramPositionCommandMotor1(fSlaveTestTargetPos, fDuration);
        fSlaveTestTargetPos -= fSlaveTestAcceleration;
        HAL_Delay(5);
      }
      break;
    }
  }
}
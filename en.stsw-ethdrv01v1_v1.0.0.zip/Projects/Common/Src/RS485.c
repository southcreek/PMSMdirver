/**
******************************************************************************
* @file           : RS485.c
* @brief          : This source files provide the interface layer for 
*                   RS485 configuration and data management   
******************************************************************************
* @attention
*
* <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
* All rights reserved.</center></h2>
*
* This software component is licensed by ST under Ultimate Liberty license
* SLA0044, the "License"; You may not use this file except in compliance with
* the License. You may obtain a copy of the License at:
*                             www.st.com/SLA0044
*
******************************************************************************
*/

#include "stm32f7xx_hal.h"
#include "stm32f7xx_nucleo_144.h"
#include "stm32f7xx_hal_gpio.h"
#include "RS485.h"
#include "main.h"
#include "Actuation.h"
#include "string.h"


uint8_t size=0;
uint16_t rx_TimeToInit=0;

extern UART_HandleTypeDef UartHandle;
extern uint8_t rx_flag;
extern uint8_t rx_buff[4];
extern uint8_t out1_status;
extern uint8_t out2_status;
extern uint8_t out1;
extern uint8_t out2;
/**
  * @brief  RS485 Initialization
  * @param  None
  * @retval None
  */
void RS485_Init(void)
{  
	/*##-1- Configure the UART peripheral ###########################*/
	/* Put the USART peripheral in the Asynchronous mode (UART Mode) */
	/* UART configured as follows:
          - Word Length = 8 Bits (7 data bit + 1 parity bit) :
            BE CAREFUL : Program 7 data bits + 1 parity bit in PC HyperTerminal
          - Stop Bit    = One Stop bit
          - Parity      = NONE
          - BaudRate    = 115200 baud
        */
USARTx_CLK_ENABLE();
	UartHandle.Instance        = nUSARTx;

	UartHandle.Init.BaudRate   = 921600;
	UartHandle.Init.WordLength = UART_WORDLENGTH_8B;
	UartHandle.Init.StopBits   = UART_STOPBITS_1;
	UartHandle.Init.Parity     = UART_PARITY_NONE;
	UartHandle.Init.HwFlowCtl  = UART_HWCONTROL_NONE;
	UartHandle.Init.Mode       = UART_MODE_TX_RX;
	UartHandle.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&UartHandle) != HAL_OK)
	{
		/* Initialization Error */
		while(1);
	}
        RS485_EN();
}



/**
  * @brief  RS485 enable pin Initialization
  * @param  None
  * @retval None
  */


void RS485_EN (void)
{
   GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
__HAL_RCC_GPIOG_CLK_ENABLE();
  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(RS485_EN_PORT, RS485_EN_PIN, GPIO_PIN_SET);

  /*Configure GPIO pins : IPS_CH1_Pin IPS_CH2_Pin */
  GPIO_InitStruct.Pin = RS485_EN_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(RS485_EN_PORT, &GPIO_InitStruct);
  
  
  /*Configure GPIO pins : IPS_CH1_Pin IPS_CH2_Pin */
  GPIO_InitStruct.Pin = RS485_CLK_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(RS485_CLK_PORT, &GPIO_InitStruct);
  
}


/**
  * @brief  RS485 Transmission 
  * @param  None
  * @retval None
  */
HAL_StatusTypeDef RS485_Transmission (uint8_t tx_value)
{  
    HAL_GPIO_WritePin(RS485_EN_PORT,RS485_EN_PIN,GPIO_PIN_SET); 
    
    HAL_UART_Transmit(&UartHandle,"\r\nInput channels value ",strlen("\r\nInput channels value "),1000);

    
    /* Digital Input voltage level*/
    if(tx_value==0xEE)
        HAL_UART_Transmit(&UartHandle,"IN1 LOW  IN2 LOW \r\n",strlen("IN1 LOW  IN2 LOW \r\n"),1000);
    else if(tx_value==0xE1)
        HAL_UART_Transmit(&UartHandle,"IN1 HIGH  IN2 LOW \r\n",strlen("IN1 HIGH  IN2 LOW \r\n"),1000);
    else if(tx_value==0x1E)
        HAL_UART_Transmit(&UartHandle,"IN1 LOW IN2 HIGH \r\n",strlen("IN1 LOW IN2 HIGH \r\n"),1000);
    else if(tx_value==0x11)
        HAL_UART_Transmit(&UartHandle,"IN1 HIGH IN2 HIGH \r\n",strlen("IN1 HIGH IN2 HIGH \r\n"),1000);
    

    /* Digital output diagnostic feedback */
        HAL_UART_Transmit(&UartHandle,"\r\nOutput channels state and diagnostic \r\n",strlen("\r\nOutput channels state and diagnostic \r\n"),1000);
        if(out1==5)
         HAL_UART_Transmit(&UartHandle,"OUT1 STATE ON \r\n",strlen("OUT1 STATE ON \r\n"),1000);
        if (out1==4)
         HAL_UART_Transmit(&UartHandle,"OUT1 STATE OFF \r\n",strlen("OUT1 STATE OFF \r\n"),1000);
        if(out2==5)
         HAL_UART_Transmit(&UartHandle,"OUT2 STATE ON \r\n",strlen("OUT2 STATE ON \r\n"),1000);
        if (out2==4)
         HAL_UART_Transmit(&UartHandle,"OUT2 STATE OFF \r\n",strlen("OUT2 STATE OFF \r\n"),1000);
        
          if(out1_status==2)
         HAL_UART_Transmit(&UartHandle,"OUT1 STATUS FAULT \r\n",strlen("OUT1 STATUS FAULT \r\n"),1000);
        if (out1_status==3)
         HAL_UART_Transmit(&UartHandle,"OUT1 STATUS GOOD \r\n",strlen("OUT1 STATUS GOOD \r\n"),1000);
        if(out2_status==2)
         HAL_UART_Transmit(&UartHandle,"OUT2 STATUS FAULT \r\n",strlen("OUT2 STATUS FAULT \r\n"),1000);
        if (out2_status==3)
         HAL_UART_Transmit(&UartHandle,"OUT2 STATUS GOOD \r\n",strlen("OUT2 STATUS GOOD \r\n"),1000);
  
  /* Digital output activation */
    if(HAL_UART_Transmit(&UartHandle,"Insert output channel value using the sequence OUT1 value,OUT2 value ",strlen("Insert output channel value using the sequence OUT1 value,OUT2 value "),1000)==HAL_OK)
    {
      while(__HAL_UART_GET_FLAG(&UartHandle,UART_FLAG_TC)==0); 
      size=sizeof(rx_buff);
      RS485_Receive(rx_buff,size); 
      UartHandle.pRxBuffPtr = rx_buff;
      UartHandle.RxXferCount = size;
      HAL_GPIO_WritePin(RS485_EN_PORT,RS485_EN_PIN,GPIO_PIN_RESET); 
      
    }
    
    
    

      
    return HAL_OK;
}


/**
  * @brief  RS485 Receiving 
  * @param  None
  * @retval None
  */
HAL_StatusTypeDef RS485_Receive (uint8_t* rx_value,uint8_t datasize)
{

  
HAL_UART_Receive_IT(&UartHandle,rx_value,datasize);

return HAL_OK;

}


/**
  * @brief  RS485 Callback function
  * @param  None
  * @retval None
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  rx_TimeToInit=0;
  rx_flag=2;

}


void RS485_CLK(void)
{
 // user can insert code here
}



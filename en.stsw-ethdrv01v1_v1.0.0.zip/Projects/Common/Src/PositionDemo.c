#include "motorcontrol.h"
#include "mc_config.h"

#include "TrajCtrl.h"
#include "PositionDemo.h"
#include "math.h"

void EncoderIndexInit(void);

#define RADTOS16 10430.378350470452725f

#ifndef M_PI
  #define M_PI 3.14159265358979323846
#endif

PosCtrl oPosCtrl[NBR_OF_MOTORS];
PID_Handle_t* oPOS;
SpeednTorqCtrl_Handle_t* oSTC[NBR_OF_MOTORS] = {&SpeednTorqCtrlM1};

// Position control demo User variables
#define ANGLESTEP (2.0f * M_PI / 24.0f) // Radiant
float movementDuration = 0.999f; // Second  (Duration*1000/9 Shall be integer multiple)
float holdTime = 0.36f;
float targetPos[] = {ANGLESTEP, -ANGLESTEP};
uint16_t targetPosIndex = 0;
#define TARGETPOSLEN 2

bool encoderAlignment = false;
bool supervisedMode = true;
bool followMode = false;

bool encoderAbsoluteAligned = true;
bool positionControl = true;

         int32_t wMecAngle      = 0;
volatile int32_t wMecAngleRef   = 0;
volatile int16_t hTorqueRef_Pos = 0;

float targetRad = 0;

PID_Handle_t PIPosParamsM1 =
{
  .hDefKpGain          = 5000,       /*!< Default Kp gain, used to initialize Kp gain
                                                                   software variable*/
  .hDefKiGain          = 500,       /*!< Default Ki gain, used to initialize Ki gain
                                                                   software variable*/
  .hKpDivisor          = 1024,                  /*!< Kp gain divisor, used in conjuction with
                                                                   Kp gain allows obtaining fractional values.
                                                                   If FULL_MISRA_C_COMPLIANCY is not defined
                                                                   the divisor is implemented through
                                                                   algebrical right shifts to speed up PI
                                                                   execution. Only in this case this parameter
                                                                   specifies the number of right shifts to be
                                                                   executed */
  .hKiDivisor          = 32768,                  /*!< Ki gain divisor, used in conjuction with
                                                                   Ki gain allows obtaining fractional values.
                                                                   If FULL_MISRA_C_COMPLIANCY is not defined
                                                                   the divisor is implemented through
                                                                   algebrical right shifts to speed up PI
                                                                   execution. Only in this case this parameter
                                                                   specifies the number of right shifts to be
                                                                   executed */
  .wUpperIntegralLimit = NOMINAL_CURRENT * (int32_t)32768,  /*!< Upper limit used to saturate the integral
                                                                   term given by Ki / Ki divisor * integral of
                                                                   process variable error */
  .wLowerIntegralLimit = -(int32_t)NOMINAL_CURRENT * (int32_t)32768, /*!< Lower limit used to saturate the integral
                                                                   term given by Ki / Ki divisor * integral of
                                                                   process variable error */
  .hUpperOutputLimit       = NOMINAL_CURRENT,                      /*!< Upper limit used to saturate the PI output
                                                               */
  .hLowerOutputLimit       = -NOMINAL_CURRENT,                     /*!< Lower limit used to saturate the PI output
                                                               */
  .hKpDivisorPOW2      = (uint16_t)10,              /*!< Kp gain divisor expressed as power of 2.
                                                                   E.g. if gain divisor is 512 the value
                                                                   must be 9 because 2^9 = 512 */
  .hKiDivisorPOW2      = (uint16_t)15,              /*!< Ki gain divisor expressed as power of 2.
                                                                   E.g. if gain divisor is 512 the value
                                                                   must be 9 because 2^9 = 512 */
  .hDefKdGain = 250,           /*!< Default Kd gain, used to initialize Kd 
                                     gain software variable */
  .hKdDivisor = 16,          /*!< Kd gain divisor, used in conjuction with 
                                     Kd gain allows obtaining fractional values. 
                                     If FULL_MISRA_C_COMPLIANCY is not defined 
                                     the divisor is implemented through 
                                     algebrical right shifts to speed up PI 
                                     execution. Only in this case this parameter
                                     specifies the number of right shifts to be 
                                     executed */
  .hKdDivisorPOW2 = (uint16_t)4      /*!< Kd gain divisor expressed as power of 2.
                                     E.g. if gain divisor is 512 the value 
                                     must be 9 because 2^9 = 512 */

};

void PositionDemoInit()
{
  oPOS = &PIPosParamsM1;
  PID_HandleInit(oPOS);
  
  TC_Init(&oPosCtrl[M1], (float)SPEED_LOOP_FREQUENCY_HZ, &SpeednTorqCtrlM1);
  
  EncoderIndexInit();
}

int32_t GetAbsolutePosition()
{
  return(SPD_GetMecAngle(STC_GetSpeedSensor(&SpeednTorqCtrlM1)));
}

void EncoderReset()
{
//  if (!encoderAbsoluteAligned)
//  {
//    ENCODER_M1._Super.wMecAngle = 0;
//    encoderAbsoluteAligned = true;
//  }
}

bool EncoderAbsouteAligned()
{
  return (encoderAbsoluteAligned == true);
}

bool isMovementComplete() {
  return TC_RampCompleted(&oPosCtrl[M1]);
}

void GoToPositionDemo(void)
{
  
  if (encoderAlignment)
  {
    static uint16_t encAlignState = 0;
    float searchAngleRad = 2.0f * M_PI / 24.0f;
    switch (encAlignState)
    {
    default:
    case 0:
      {
        encoderAbsoluteAligned = false;
        wMecAngleRef = SPD_GetMecAngle(STC_GetSpeedSensor(oSTC[M1]));
        TC_ExecPosCmd(&oPosCtrl[M1], (float)(wMecAngleRef) / RADTOS16, searchAngleRad , 1.0f); // 1 giro in 2 secondi per cercare il segnale Z
        encAlignState = 1;
      }
      break;
    case 1:
      {
        wMecAngleRef = (int32_t)(TC_Exec(&oPosCtrl[M1]) * RADTOS16);
        
        if (TC_RampCompleted(&oPosCtrl[M1]))
        {
          TC_ExecPosCmd(&oPosCtrl[M1], (float)(wMecAngleRef) / RADTOS16, -(searchAngleRad * 2) , 2.0f); // 1 giro in 2 secondi per cercare il segnale Z
        }
        
        if (encoderAbsoluteAligned)
        {
          wMecAngleRef = SPD_GetMecAngle(STC_GetSpeedSensor(oSTC[M1]));
          encoderAlignment = false;
          encAlignState = 0;
          supervisedMode = true;
        }
      }
      break;
    }
  }
  
  if (supervisedMode)
  {
    if (followMode == true)
    {
      wMecAngleRef = (int32_t)(TC_Follow(&oPosCtrl[M1]) * RADTOS16);
      //wMecAngleRef = SPD_GetMecAngle(STC_GetSpeedSensor(oSTC[M1]));
    } else {
      wMecAngleRef = SPD_GetMecAngle(STC_GetSpeedSensor(oSTC[M1]));
    }
  }
  
  if (positionControl)
  {
    // POS PI
    wMecAngle = SPD_GetMecAngle(STC_GetSpeedSensor(oSTC[M1]));
    int32_t wError = wMecAngleRef - wMecAngle;
    hTorqueRef_Pos = PID_Controller(oPOS, wError);
    
    MC_ProgramTorqueRampMotor1(hTorqueRef_Pos , 0);
  } else
  {
    MC_ProgramTorqueRampMotor1(0 , 0);
  }
}

void GoToPosition(float targetRadiant)
{
  wMecAngleRef = (int32_t)(TC_FollowPosCmd(&oPosCtrl[M1], targetRadiant) * RADTOS16);
  followMode = true;
}

void EncoderIndexInit(void)
{
}
#ifndef __POSITIONDEMO_H
#define __POSITIONDEMO_H

void PositionDemoInit();
void GoToPositionDemo();
void EncoderReset();
void GoToPosition(float targetRadiant);
bool isMovementComplete();    // True if the movement has been completed false otherwise
bool EncoderAbsouteAligned(); // True if aligned false otherwise

#endif // __POSITIONDEMO_H
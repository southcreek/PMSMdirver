
#define RS485_EN_PIN            GPIO_PIN_12
#define RS485_EN_PORT           GPIOG
#define RS485_CLK_PIN           GPIO_PIN_8
#define RS485_CLK_PORT          GPIOC

/* Definition for USARTx clock resources */
#define nUSARTx                           USART6
#define USARTx_CLK_ENABLE()              __HAL_RCC_USART6_CLK_ENABLE();
#define USARTx_RX_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOG_CLK_ENABLE()
#define USARTx_TX_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOG_CLK_ENABLE()


/* Definition for USARTx Pins */
#define USARTx_TX_PIN                    GPIO_PIN_14
#define USARTx_TX_GPIO_PORT              GPIOG
#define USARTx_TX_AF                     GPIO_AF8_USART6
#define USARTx_RX_PIN                    GPIO_PIN_9
#define USARTx_RX_GPIO_PORT              GPIOG
#define USARTx_RX_AF                     GPIO_AF8_USART6

/* Function Declaration */
HAL_StatusTypeDef RS485_Transmission (uint8_t tx_value);
HAL_StatusTypeDef RS485_Receive (uint8_t* rx_value,uint8_t datasize);
void RS485_EN (void);
void RS485_CLK(void);
void RS485_Init(void);
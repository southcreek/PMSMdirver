#ifndef __MC_MAIN_H
#define __MC_MAIN_H

#define SLAVE_ID 1

#define SLAVE_ADDR (SLAVE_ID - 1)
#define DONE_BIT ((1) << SLAVE_ADDR)

#define CMD_STARTALIGN  0x01
#define CMD_GETSTATUS   0x02
#define CMD_SETPOSITION 0x03
#define CMD_CLEAR_FAULT 0x04
#define CMD_STOP_MOTOR  0x05
#define CMD_RESET       0x06
#define CMD_ENCALIGN    0x07

#define SLAVE_STATUS_READY      0x01
#define SLAVE_STATUS_ALIGNED    0x06
#define SLAVE_STATUS_POSITIONED 0x07
#define SLAVE_STATUS_FAULT      0x08
#define SLAVE_STATUS_ERROR      0xFF

void main_mc_loop(void);

#endif  //__MC_MAIN_H

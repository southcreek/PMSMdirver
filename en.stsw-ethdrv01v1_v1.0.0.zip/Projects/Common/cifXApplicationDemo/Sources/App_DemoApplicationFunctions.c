/**************************************************************************************
Exclusion of Liability for this demo software:
  The following software is intended for and must only be used for reference and in an
  evaluation laboratory environment. It is provided without charge and is subject to
  alterations. There is no warranty for the software, to the extent permitted by
  applicable law. Except when otherwise stated in writing the copyright holders and/or
  other parties provide the software "as is" without warranty of any kind, either
  expressed or implied.
  Please refer to the Agreement in README_DISCLAIMER.txt, provided together with this file!
  By installing or otherwise using the software, you accept the terms of this Agreement.
  If you do not agree to the terms of this Agreement, then do not install or use the
  Software!
**************************************************************************************/

/**************************************************************************************

Copyright (c) Hilscher Gesellschaft fuer Systemautomation mbH. All Rights Reserved.

***************************************************************************************/

/*****************************************************************************/
/*! General Inclusion Area                                                   */
/*****************************************************************************/

#include "App_DemoApplication.h"
#include "App_PacketCommunication.h"

/*****************************************************************************/
/*! FUNCTIONS                                                                */
/*****************************************************************************/



/**************************************************************************************/
/*! This function performs an application specific self test.
 */
/**************************************************************************************/
void App_Selftest(void)
{
  uint16_t usData;
  uint8_t  bData;

  #define SELFTEST_DELAY_MS 200

  HOSTAL_Device_SetStatus(HOSTAL_DEVICE_STATUS_ALARM);
  HOSTAL_Sleep(SELFTEST_DELAY_MS);
  HOSTAL_Device_ClearStatus(HOSTAL_DEVICE_STATUS_ALARM);

  HOSTAL_Device_SetStatus(HOSTAL_DEVICE_STATUS_ERROR);
  HOSTAL_Sleep(SELFTEST_DELAY_MS);
  HOSTAL_Device_ClearStatus(HOSTAL_DEVICE_STATUS_ERROR);

  HOSTAL_Device_SetStatus(HOSTAL_DEVICE_STATUS_DATA);
  HOSTAL_Sleep(SELFTEST_DELAY_MS);
  HOSTAL_Device_ClearStatus(HOSTAL_DEVICE_STATUS_DATA);

  HOSTAL_Actuator_SetData(0, 0xAAAA);
  HOSTAL_Sleep(SELFTEST_DELAY_MS);
  HOSTAL_Actuator_SetData(0, 0x0000);

  HOSTAL_Actuator_SetData(1, 0xAAAA);
  HOSTAL_Sleep(SELFTEST_DELAY_MS);
  HOSTAL_Actuator_SetData(1, 0x0000);

  HOSTAL_Sensor_GetData(0, &usData);
  HOSTAL_Actuator_SetData(0, usData);
  HOSTAL_Sleep(SELFTEST_DELAY_MS);

  HOSTAL_Sensor_GetData(1, &usData);
  HOSTAL_Actuator_SetData(1, usData);
  HOSTAL_Sleep(SELFTEST_DELAY_MS);

  HOSTAL_RotarySwitch_GetValue(0, &bData);
  HOSTAL_Actuator_SetData(0, (uint32_t)bData);
  HOSTAL_RotarySwitch_GetValue(1, &bData);
  HOSTAL_Actuator_SetData(1, (uint32_t)bData);
  HOSTAL_Sleep(SELFTEST_DELAY_MS);
}

/**************************************************************************************/
/*! Read board information
 *
 * \param hDriver     [in]   Handle if cifX driver
 * \param ptBoardInfo [out]  Board information
 */
/**************************************************************************************/
void App_ReadBoardInfo(const CIFXHANDLE   hDriver,
                        BOARD_INFORMATION* const ptBoardInfo)
{
  CIFXHANDLE hSys = NULL;
  SYSTEM_CHANNEL_SYSTEM_INFO_BLOCK tSysInfo = ptBoardInfo->tSystemInfo;
  long lRet = 0;      /** Return value for common error codes  */

  /** Retrieve board 0 information */
  if(CIFX_NO_ERROR != (lRet = xDriverEnumBoards(hDriver, 0, sizeof(BOARD_INFORMATION), ptBoardInfo)))
  {
    printf("No board with the given index available: 0x%08X !\r\n", (unsigned int) lRet);
  }
  else if(CIFX_NO_ERROR != (lRet = xSysdeviceOpen(hDriver, "cifX0", &hSys)))
  {
    printf("Error opening SystemDevice: 0x%08X !\r\n", (unsigned int) lRet);
  }
  /** System channel successfully opened, try to read the System Info Block */
  else if(CIFX_NO_ERROR != (lRet = xSysdeviceInfo(hSys, CIFX_INFO_CMD_SYSTEM_INFO_BLOCK, sizeof(tSysInfo), &tSysInfo)))
  {
    printf("Error querying system information block: 0x%08X !\r\n", (unsigned int) lRet);
  }
  else
  {
    printf("System Channel Info Block:\r\n");
    printf("DPM Size         : %u\r\n", (unsigned int)tSysInfo.ulDpmTotalSize);
    printf("Device Number    : %u\r\n", (unsigned int)tSysInfo.ulDeviceNumber);
    printf("Serial Number    : %u\r\n", (unsigned int)tSysInfo.ulSerialNumber);
    printf("Manufacturer     : %u\r\n", (unsigned int)tSysInfo.usManufacturer);
    printf("Production Date  : %u\r\n", (unsigned int)tSysInfo.usProductionDate);
    printf("Device Class     : %u\r\n", (unsigned int)tSysInfo.usDeviceClass);
    printf("HW Revision      : %u\r\n", (unsigned int)tSysInfo.bHwRevision);
    printf("HW Compatibility : %u\r\n", (unsigned int)tSysInfo.bHwCompatibility);

    xSysdeviceClose(hSys);
  }
}

/**************************************************************************************/
/*! Read channel information
 *
 *   \param hChannel      [in]  Handle of cifX channel
 *   \param ptChannelInfo [out] Channel information
 */
/**************************************************************************************/
void App_ReadChannelInfo(const CIFXHANDLE           hChannel,
                          CHANNEL_INFORMATION* const ptChannelInfo)
{
  long lRet = 0; /** Return value for common error codes      */

  /** Retrieve the global communication channel information */
  if(CIFX_NO_ERROR != (lRet = xChannelInfo(hChannel, sizeof(CHANNEL_INFORMATION), ptChannelInfo)))
  {
    printf("Error querying communication channel information block: 0x%08X !\r\n", (unsigned int) lRet);
  }
  else
  {
    printf("Communication Channel Info:\r\n");
    printf("Device Number   : %u\r\n", (unsigned int) ptChannelInfo->ulDeviceNumber);
    printf("Serial Number   : %u\r\n", (unsigned int) ptChannelInfo->ulSerialNumber);
    printf("Firmware        : %s\r\n", ptChannelInfo->abFWName);
    printf("FW Version      : %u.%u.%u build %u\r\n", 
                                       (unsigned int) ptChannelInfo->usFWMajor,
                                       (unsigned int) ptChannelInfo->usFWMinor,
                                       (unsigned int) ptChannelInfo->usFWRevision,
                                       (unsigned int) ptChannelInfo->usFWBuild);
    printf("FW Date         : %02u/%02u/%04u\r\n", 
                                       (unsigned int) ptChannelInfo->bFWMonth,
                                       (unsigned int) ptChannelInfo->bFWDay,
                                       (unsigned int) ptChannelInfo->usFWYear);
    printf("Mailbox Size    : %u\r\n", (unsigned int) ptChannelInfo->ulMailboxSize);
  }
}

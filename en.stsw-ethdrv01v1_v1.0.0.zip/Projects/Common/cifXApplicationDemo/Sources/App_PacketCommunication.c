/**************************************************************************************
Exclusion of Liability for this demo software:
  The following software is intended for and must only be used for reference and in an
  evaluation laboratory environment. It is provided without charge and is subject to
  alterations. There is no warranty for the software, to the extent permitted by
  applicable law. Except when otherwise stated in writing the copyright holders and/or
  other parties provide the software "as is" without warranty of any kind, either
  expressed or implied.
  Please refer to the Agreement in README_DISCLAIMER.txt, provided together with this file!
  By installing or otherwise using the software, you accept the terms of this Agreement.
  If you do not agree to the terms of this Agreement, then do not install or use the
  Software!
**************************************************************************************/

/**************************************************************************************

Copyright (c) Hilscher Gesellschaft fuer Systemautomation mbH. All Rights Reserved.

***************************************************************************************/

/*****************************************************************************/
/*! General Inclusion Area                                                   */
/*****************************************************************************/

#include <string.h>
#include <stdio.h>

#include "App_PacketCommunication.h"

/*****************************************************************************/
/*! STRUCTURES                                                               */
/*****************************************************************************/

typedef struct PACKET_COMMUNICATION_COUNTER_Ttag
{
  uint32_t ulPacketSendCountSuccess;
  uint32_t ulPacketSendCountError;
  uint32_t ulPacketReceiveCount;

} PACKET_COMMUNICATION_COUNTER_T;

/******************************************************************************/

/** Structure to store application's indication handler. */
typedef struct SYNC_PACKET_INTERFACE_INDICATOR_HANDLER_Ttag
{
  bool     (*fnHandler)(CIFX_PACKET* ptPacket, void* pvUserData);
  void*      pvUserData;
} SYNC_PACKET_INTERFACE_INDICATOR_HANDLER_T;

/******************************************************************************/

#define SYNC_PACKET_INTERFACE_CNF_RECEIVE_QUEUE_DEPTH 3

typedef struct SYNC_PACKET_INTERFACE_QUEUED_PACKET_Ttag
{
  bool        fUsed;
  CIFX_PACKET tPacket;
} SYNC_PACKET_INTERFACE_QUEUED_PACKET_T;


/*****************************************************************************/
/*! GLOBAL, STATIC OR EXTERN VARIABLES                                       */
/*****************************************************************************/

/** Static packet ID counter.
 * This counter is used to assign received confirmation
 * packets uniquely to a previously sent request packet. */
static uint32_t s_ulNextPacketId = 1;

/** The LookupCommandCode function is used to print readable text instead of just the command ID. */
extern char* LookupCommandCode(uint32_t ulCmd);

/** Statistic counter for sent/received packets */
static PACKET_COMMUNICATION_COUNTER_T s_tPacketCounter = {0};

/** Storage for Application's indication handler */
static SYNC_PACKET_INTERFACE_INDICATOR_HANDLER_T s_atIndicationHandler = { 0 };

/** Receive queue for confirmation packets that are not expected when sending a request via Pkt_SendReceivePacket() */
static SYNC_PACKET_INTERFACE_QUEUED_PACKET_T s_atReceiveQueue[SYNC_PACKET_INTERFACE_CNF_RECEIVE_QUEUE_DEPTH] = {{ 0 }};

/*****************************************************************************/
/*! FUNCTIONS                                                                */
/*****************************************************************************/

/*****************************************************************************/
/*! Displays a hex dump on the debug console (16 bytes per line)
 *
 *   \param pbData    [in]  Data buffer that shall be dumped
 *   \param ulDataLen [in]  Number of bytes in pbData
 */
/*****************************************************************************/
static void
Pkt_DumpData( unsigned char* pbData,
              unsigned long  ulDataLen )
{
  unsigned long ulIdx;

  if(CIFX_MAX_DATA_SIZE < ulDataLen)
  {
    ulDataLen = CIFX_MAX_DATA_SIZE;
  }

  for(ulIdx = 0; ulIdx < ulDataLen; ++ulIdx)
  {
    if(0 == (ulIdx % 16))
      printf(NEWLINE);

    printf("%02X ", pbData[ulIdx]);
  }

  printf(NEWLINE);
}

/*****************************************************************************/
/*! Dumps a packet to the debug console
 *
 *   \param ptPacket  [in] Packet to be dumped
 */
/*****************************************************************************/
static void
Pkt_DumpPacket( CIFX_PACKET* ptPacket )
{
  printf("Dest   : 0x%08X      ID   : 0x%08X" NEWLINE, (unsigned int) ptPacket->tHeader.ulDest, (unsigned int) ptPacket->tHeader.ulId);
  printf("Src    : 0x%08X      Sta  : 0x%08X" NEWLINE, (unsigned int) ptPacket->tHeader.ulSrc, (unsigned int) ptPacket->tHeader.ulState);
  printf("DestID : 0x%08X      Cmd  : 0x%08X" NEWLINE, (unsigned int) ptPacket->tHeader.ulDestId, (unsigned int) ptPacket->tHeader.ulCmd);
  printf("SrcID  : 0x%08X      Ext  : 0x%08X" NEWLINE, (unsigned int) ptPacket->tHeader.ulSrcId, (unsigned int) ptPacket->tHeader.ulExt);
  printf("Len    : 0x%08X      Rout : 0x%08X" NEWLINE, (unsigned int) ptPacket->tHeader.ulLen, (unsigned int) ptPacket->tHeader.ulRout);

  if( ptPacket->tHeader.ulLen )
  {
    printf("Data:");

    /** Displays a hex dump on the debug console (16 bytes per line) */
    Pkt_DumpData(ptPacket->abData, ptPacket->tHeader.ulLen);
  }

  printf(NEWLINE);
}

/*****************************************************************************/
/*****************************************************************************/
uint32_t
Pkt_SendPacket( CIFXHANDLE   hChannel,
                CIFX_PACKET* ptSendPkt,
                uint32_t     ulTimeout )
{
  uint32_t lRet = CIFX_NO_ERROR;

  lRet = xChannelPutPacket(hChannel, ptSendPkt, ulTimeout);

  if(CIFX_NO_ERROR == lRet)
  {
    s_tPacketCounter.ulPacketSendCountSuccess++;

#ifndef DEMO_QUIET
    printf("========================================================" NEWLINE);
    printf("Sent packet:" NEWLINE);
    Pkt_DumpPacket(ptSendPkt);
    printf("========================================================" NEWLINE);
#endif
  }
  else
  {
    s_tPacketCounter.ulPacketSendCountError++;

#ifndef DEMO_QUIET
    printf("========================================================" NEWLINE);
    printf("Sending packet failed with error: 0x%08x" NEWLINE, (unsigned int)lRet);
    Pkt_DumpPacket(ptSendPkt);
    printf("========================================================" NEWLINE);
#endif
  }

  return lRet;
}

/**************************************************************************************/
/*! Retrieve a packet from the channel mailbox
 *
 *   \param hChannel   [in]  Communication channel handle acquired by xChannelOpen
 *   \param ptRecvPkt  [out] Received packet if function succeeds
 *   \param ulTimeout  [in]  Time in ms to wait for available message
 *
 *   \return CIFX_NO_ERROR on success
 */
/**************************************************************************************/
static uint32_t
Pkt_ReceivePacket( CIFXHANDLE   hChannel,
                   CIFX_PACKET* ptRecvPkt,
                   uint32_t     ulTimeout )
{
  uint32_t lRet = CIFX_NO_ERROR;

  lRet = xChannelGetPacket(hChannel, sizeof(*ptRecvPkt), ptRecvPkt, ulTimeout);

#ifndef DEMO_QUIET
  if(CIFX_NO_ERROR == lRet)
  {
    printf("========================================================" NEWLINE);
    printf("received packet:" NEWLINE);
    Pkt_DumpPacket(ptRecvPkt);
    printf("========================================================" NEWLINE);
  }
#endif

  return lRet;
}

/**************************************************************************************/
/**************************************************************************************/

bool
Pkt_RegisterIndicationHandler( bool (*fnHandler)( CIFX_PACKET* ptPacket,
                                                  void* pvUserData ),
                               void* pvUserData )
{
  if( NULL == s_atIndicationHandler.fnHandler )
  {
    s_atIndicationHandler.fnHandler  = fnHandler;
    s_atIndicationHandler.pvUserData = pvUserData;
    return true;
  }
  else
  {
    return false;
  }
}

/**************************************************************************************/
/*! Put a packet into the confirmation queue
 *
 *   \param ptPacket   [in]  Packet to be put into the queue
 *
 *   \return true:  Packet could be queued
 *           false: Packet could not be queued
 */
/**************************************************************************************/
static bool
Pkt_QueueConfirmation( CIFX_PACKET* ptPacket )
{
  int i;
  for (i = 0; i < SYNC_PACKET_INTERFACE_CNF_RECEIVE_QUEUE_DEPTH; i++)
  {
    if (s_atReceiveQueue[i].fUsed == false)
    {
      s_atReceiveQueue[i].fUsed   = true;
      s_atReceiveQueue[i].tPacket = *ptPacket;
      return true;
    }
  }
  return false;
}

/**************************************************************************************/
/*! Get a packet from the confirmation queue
 *
 *   \param ptPacket [out]  Packet dequeued from the confirmation queue.
 *
 *   \return true:  Packet could be queued
 *           false: Packet could not be queued
 */
/**************************************************************************************/
static bool Pkt_GetPacketFromQueue( CIFX_PACKET* ptPacket )
{
  int i;
  for (i = 0; i < SYNC_PACKET_INTERFACE_CNF_RECEIVE_QUEUE_DEPTH; i++)
  {
    if( s_atReceiveQueue[i].fUsed == true )
    {
      *ptPacket                 = s_atReceiveQueue[i].tPacket;
      s_atReceiveQueue[i].fUsed = false;
      return true;
    }
  }
  return false;
}

/**************************************************************************************/
/*! Get a specific packet (with matching ulCmd and ulId) from the confirmation queue.
 *
 *   \param ulCmd    [in]   ulCmd value of the wanted packet
 *   \param ulId     [in]   ulId value  of the wanted packet
 *   \param ptPacket [out]  Packet dequeued from the confirmation queue.
 *
 *   \return true:  Packet was found
 *           false: Packet could not be found
 */
/**************************************************************************************/
static bool Pkt_TryDequeConfirmation( uint32_t     ulCmd,
                                      uint32_t     ulId,
                                      CIFX_PACKET* ptPacket )
{
  int i;
  for (i = 0; i < SYNC_PACKET_INTERFACE_CNF_RECEIVE_QUEUE_DEPTH; i++)
  {
    if( (s_atReceiveQueue[i].fUsed == true)                  &&
        (s_atReceiveQueue[i].tPacket.tHeader.ulCmd == ulCmd) &&
        (s_atReceiveQueue[i].tPacket.tHeader.ulId == ulId)
       )
    {
      *ptPacket                 = s_atReceiveQueue[i].tPacket;
      s_atReceiveQueue[i].fUsed = false;
      return true;
    }
  }
  return false;
}

/**************************************************************************************/
/*! Dispatch a packet to the registered indication handler
 *
 *   \param ptPacket [out]  Packet that shall be dispatched
 *
 *   \return true:  Packet could be dispatched
 *           false: Packet could not be dispatched (no registered indication handler available)
 */
/**************************************************************************************/

static bool
Pkt_DispatchIndication( CIFX_PACKET* ptPacket )
{
  /* Dispatch this indication */
  if( s_atIndicationHandler.fnHandler )
  {
    return s_atIndicationHandler.fnHandler( ptPacket, s_atIndicationHandler.pvUserData );
  }
  else
  {
    return false;
  }
}

/**************************************************************************************/
/**************************************************************************************/

uint32_t
Pkt_CheckReceiveMailbox( CIFXHANDLE   hChannel,
                         CIFX_PACKET* ptPacket )
{
  uint32_t ulRet = CIFX_NO_ERROR;

  /* First, let's see if there are some unprocessed confirmations in our queue. */
  if( false == Pkt_GetPacketFromQueue( ptPacket ) )
  {
    /* No packets in the confirmation queue --> check the receive mailbox. */
    ulRet = Pkt_ReceivePacket( hChannel, ptPacket, RX_TIMEOUT );
  }

  if( CIFX_NO_ERROR == ulRet )
  {
#if !defined( DEMO_QUIET ) && !defined( DEMO_DONT_USE_COMMAND_LOOKUP )
    printf( "[ok] IND:           Packet ulCmd 0x%08x (%s)" NEWLINE NEWLINE,
            (unsigned int)ptPacket->tHeader.ulCmd,
            LookupCommandCode(ptPacket->tHeader.ulCmd) );
#endif
    if( !Pkt_DispatchIndication( ptPacket ) )
    {
      /* Indication was not handled, so we send the response on our own. */
      ptPacket->tHeader.ulCmd   |= 0x01; /* Make it a response */
      ptPacket->tHeader.ulLen    = 0;
      ptPacket->tHeader.ulState  = CIFX_INVALID_COMMAND;

      Pkt_SendPacket( hChannel, ptPacket, TX_TIMEOUT );
    }
  }

  return ulRet;
}

/**************************************************************************************/
/**************************************************************************************/

uint32_t
Pkt_SendReceivePacket( CIFXHANDLE   hChannel,
                       CIFX_PACKET* ptPacket,
                       uint32_t     ulTimeout )
{
  uint32_t ulRet      = CIFX_NO_ERROR;
  uint32_t ulCmd      = ptPacket->tHeader.ulCmd;
  uint32_t ulPacketId = s_ulNextPacketId++;

  ptPacket->tHeader.ulDest = LOCAL_CHANNEL;
  ptPacket->tHeader.ulId   = ulPacketId;

  /* issue the request */
  ulRet = Pkt_SendPacket( hChannel, ptPacket, ulTimeout );

  if( CIFX_NO_ERROR != ulRet )
  {
#if !defined( DEMO_QUIET ) && !defined( DEMO_DONT_USE_COMMAND_LOOKUP )
    printf( "[!!] REQ:      Packet ulCmd 0x%08x (%s) failed with error 0x%08x" NEWLINE NEWLINE,
            (unsigned int)ptPacket->tHeader.ulCmd,
            LookupCommandCode(ptPacket->tHeader.ulCmd),
            (unsigned int)ulRet );
#endif
  }
  else
  {
    /* Sending the packet succeeded */

#if !defined( DEMO_QUIET ) && !defined( DEMO_DONT_USE_COMMAND_LOOKUP )
    printf( "[ok] REQ:           Packet ulCmd 0x%08x (%s)" NEWLINE NEWLINE,
            (unsigned int)ulCmd,
            LookupCommandCode(ptPacket->tHeader.ulCmd) );
#endif

    /* Now, let's wait for the confirmation. All indications coming up in the meantime will be dispatched. */
    while( 1 )
    {
      ulRet = Pkt_ReceivePacket( hChannel, ptPacket, ulTimeout );

      if (CIFX_NO_ERROR == ulRet)
      {
        if ((ptPacket->tHeader.ulCmd == (ulCmd | 0x1)) && (ptPacket->tHeader.ulId == ulPacketId))
        {
          /* This is the confirmation we were waiting for. */
          break;
        }
        else if (ptPacket->tHeader.ulCmd & 0x1)
        {
          /* This is a confirmation for another command we have issued, so put it into the receive queue for now. */
          #if !defined( DEMO_QUIET ) && !defined( DEMO_DONT_USE_COMMAND_LOOKUP )
          printf( "Warning: Unexpected confirmation packet queued! Are you recursively issuing commands in your indication handler!?!" NEWLINE );
          #endif
          Pkt_QueueConfirmation( ptPacket );
        }
        else
        {
          if( !Pkt_DispatchIndication( ptPacket ) )
          {
            /* Indication was not handled, so we send the response on our own. */
            ptPacket->tHeader.ulCmd   |= 0x01; /* Make it a response */
            ptPacket->tHeader.ulLen    = 0;
            ptPacket->tHeader.ulState  = CIFX_INVALID_COMMAND;

            Pkt_SendPacket( hChannel, ptPacket, TX_TIMEOUT );
          }

          if( Pkt_TryDequeConfirmation((ulCmd | 0x1), ulPacketId, ptPacket) )
          {
            /* The confirmation we are waiting for was queued up during indication handling, we're fine. */
            #if !defined( DEMO_QUIET ) && !defined( DEMO_DONT_USE_COMMAND_LOOKUP )
            printf( "A queued-up confirmation packet was processed!" NEWLINE NEWLINE );
            #endif
            break;
          }
        }
      }
      else if( CIFX_DEV_GET_NO_PACKET == ulRet )
      {
        /* No packet within the given timeout received. */
        break;
      }
    }

    if( CIFX_NO_ERROR == ulRet )
    {
      #if !defined( DEMO_QUIET ) && !defined( DEMO_DONT_USE_COMMAND_LOOKUP )
      if (ptPacket->tHeader.ulState == 0)
      {
        printf( "[ok] REQ->CNF:      Packet ulCmd 0x%08x (%s)" NEWLINE NEWLINE,
                (unsigned int)ulCmd,
                LookupCommandCode(ptPacket->tHeader.ulCmd) );
      }
      else
      {
        printf( "[!!] REQ->CNF:      Packet ulCmd 0x%08x (%s)  Status 0x%08x " NEWLINE NEWLINE,
                (unsigned int)ulCmd,
                LookupCommandCode(ptPacket->tHeader.ulCmd),
                (unsigned int)ptPacket->tHeader.ulState );
      }
      #endif
    }
    else
    {
      #if !defined( DEMO_QUIET )
      printf( "[!!] SEND/RECV of packet failed with Status: 0x%08x" NEWLINE NEWLINE, (unsigned int)ulRet );
      #endif
    }
  }

  return ulRet;
}

/**************************************************************************************/
/**************************************************************************************/


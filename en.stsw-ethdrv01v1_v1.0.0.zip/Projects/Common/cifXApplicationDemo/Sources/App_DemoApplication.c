/**************************************************************************************
Exclusion of Liability for this demo software:
  The following software is intended for and must only be used for reference and in an
  evaluation laboratory environment. It is provided without charge and is subject to
  alterations. There is no warranty for the software, to the extent permitted by
  applicable law. Except when otherwise stated in writing the copyright holders and/or
  other parties provide the software "as is" without warranty of any kind, either
  expressed or implied.
  Please refer to the Agreement in README_DISCLAIMER.txt, provided together with this file!
  By installing or otherwise using the software, you accept the terms of this Agreement.
  If you do not agree to the terms of this Agreement, then do not install or use the
  Software!
**************************************************************************************/

/**************************************************************************************

Copyright (c) Hilscher Gesellschaft fuer Systemautomation mbH. All Rights Reserved.

***************************************************************************************/

/**************************************************************************************/
/*! General Inclusion Area                                                            */
/**************************************************************************************/

#include "App_DemoApplication.h"
#include <stdbool.h>
#include "App_EventHandler.h"
#include "App_PacketCommunication.h"
#include "App_TerminalHandler.h"
#include "Hil_DualPortMemory.h"
#include "mc_main.h"


/**************************************************************************************/
/*! FUNCTIONS                                                                         */
/**************************************************************************************/
APP_PROCESS_DATA_INPUT_T  rxValue;
APP_PROCESS_DATA_OUTPUT_T txValue;
/**************************************************************************************/
/*! Entry point of cifX Application Demo.
 *
 * \return CIFX_NO_ERROR on success
 */
/**************************************************************************************/


int App_CifXApplicationDemo(void)
{
  APP_DATA_T tAppData;
  CIFXHANDLE hDriver  = NULL;  /** Handle of cifX driver               */
  int32_t   lRet      = 0;     /** Return value for common error codes */
  uint32_t  ulState   = 0;     /** Actual state returned               */
  uint32_t  ulTimeout = 1000;  /** Timeout in milliseconds             */

  printf("---------- cifX Application Demo ----------\r\n");

  /* Initialize application demo resources. */
  memset(&tAppData, 0, sizeof(tAppData));

  tAppData.fRunning = true;

  lRet = HOSTAL_Init();

  if(HOSTAL_OK == lRet)
  {
    App_Selftest();
  }

  /** Opens the driver, allowing access to every driver function */
  if(HOSTAL_OK == lRet)
  {
    lRet = xDriverOpen(&hDriver);
  }
  if(CIFX_NO_ERROR != lRet)
  {
    printf("ERROR: xDriverOpen failed: 0x%08x\r\n", (unsigned int) lRet);
    return lRet;
  }
  else
  {
    /** Driver successfully opened */
    App_ReadBoardInfo(hDriver, &tAppData.tBoardInfo);

    /** Opens a connection to a communication channel */
    lRet = xChannelOpen(hDriver, "cifX0", 0, &tAppData.hChannel);

    if(CIFX_NO_ERROR != lRet)
    {
      printf("Error opening Channel: 0x%08X\r\n", (unsigned int) lRet);
      /** Closes an open connection to the driver */
      xDriverClose(hDriver);
      hDriver = NULL;
      return lRet;
    }
    else
    {
      /** Communication Channel successfully opened */
      
      /** Waiting for HIL_COMM_COS_READY flag is set properly */
      do
      {
        xChannelInfo(tAppData.hChannel, sizeof(CHANNEL_INFORMATION), &tAppData.tChannelInfo[0]);
      }
      while (!(tAppData.tChannelInfo[0].ulDeviceCOSFlags & HIL_COMM_COS_READY) || (tAppData.tChannelInfo[0].ulDeviceCOSFlags == CIFX_DPM_NO_MEMORY_ASSIGNED));

      /** reads and displays communication channel Information */
      App_ReadChannelInfo(tAppData.hChannel, &tAppData.tChannelInfo[0]);

      /** Set the Application state flag in the application COS flags */
      lRet = xChannelHostState(tAppData.hChannel, CIFX_HOST_STATE_READY, &ulState, ulTimeout);
      if(lRet == CIFX_NO_ERROR)
      {
        /** register App_IODataHandler as timer callback function */
        if(HOSTAL_OK == (lRet = HOSTAL_Callback_Register(HOSTAL_CB_TIMER, App_IODataHandler, (void*)&tAppData)))
        {
          /** enable callback functions only after timer callback function is registered */
          lRet = HOSTAL_Callbacks_Enable();
        }
        else
        {
          printf("fails to register timer callback function!\r\n");
        }
      }

      if(lRet == CIFX_NO_ERROR)
      {
        lRet = Protocol_StartConfiguration(&tAppData);
      }
      
      if(lRet != CIFX_NO_ERROR){
        /** error handling */
      }

      /** now the bus is running */
      while(tAppData.fRunning && lRet == CIFX_NO_ERROR)
      {
        /** check and process incoming packets */
        lRet = Protocol_PacketHandler(&tAppData);
        
        // MC
         
        main_mc_loop();
        

        /** check and process input from terminal (UART console) */
//        App_TerminalHandler(&tAppData);

        /** check for events (DIP switches, changed variable values, etc.) */
//        App_EventHandler(&tAppData);

        HOSTAL_Sleep(1);
      }

      /** remove calling of App_IODataHandler, because we don't have valid IO Data any more */
      HOSTAL_Callbacks_Disable();
      HOSTAL_Callback_Register(HOSTAL_CB_TIMER, NULL, NULL);

      /** Set the bus state flag in the application COS state flags, to stop communication */
      xChannelBusState(tAppData.hChannel, CIFX_BUS_STATE_OFF, &ulState, 10);

      /** Set Host not ready to stop bus communication */
      xChannelHostState(tAppData.hChannel, CIFX_HOST_STATE_NOT_READY, &ulState, ulTimeout);
    }

    /** Close a connection to a communication channel */
    xChannelClose(tAppData.hChannel);
    tAppData.hChannel = NULL;
    tAppData.fRunning = false;
  }

  /** Closes an open connection to the driver */
  xDriverClose(hDriver);
  hDriver = NULL;

  printf(" State = 0x%08X !\r\n", (unsigned int) lRet);
  printf("----------------------------------------------------\r\n");

  return lRet;
}

/**************************************************************************************/
/*! Cyclic IO data handler: fast data exchange with netX via DPM called from a timer ISR
 *
 * \param ptAppData  [in]  Pointer to application data
 */
/**************************************************************************************/
void App_IODataHandler(void* ptAppResources)
{
  long            lRet      = CIFX_NO_ERROR; /** Return value for common error codes  */
  APP_DATA_T*     ptAppData = (APP_DATA_T*)ptAppResources;

  if(ptAppData->hChannel != NULL)
  {

    /** INPUT DATA *********************************************************************/
    lRet = xChannelIORead(ptAppData->hChannel, 0, 0, sizeof(ptAppData->tInputData), &ptAppData->tInputData, 0);
    if(lRet != CIFX_NO_ERROR)
    {
      /** Something failed?
       * Reason for error could be:
       * 1) netX is not "ready" yet. May happen during startup.
       * 2) netX is not "running" yet. May happen during startup in case the netX is not fully configured yet.
       * 3) netX has not yet established an IO connection. */

      ptAppData->fInputDataValid = false;
    }
    else
    {
      /** process newly received input data image */
      ptAppData->fInputDataValid = true;

      rxValue = ptAppData->tInputData;
    }

    /** OUTPUT DATA ***************************************/
    /** update output data image to be sent in this cycle */

    ptAppData->tOutputData = txValue;
    
    lRet = xChannelIOWrite(ptAppData->hChannel, 0, 0, sizeof(ptAppData->tOutputData), &ptAppData->tOutputData, 0);
    if(lRet != CIFX_NO_ERROR)
    {
      /** Something failed?
       * Reason for error could be:
       * 1) netX is not "ready" yet. May happen during startup.
       * 2) netX is not "running" yet. May happen during startup in case the netX is not fully configured yet.
       * 3) netX has not yet established an IO connection. */
    }
  }
}


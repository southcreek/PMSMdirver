/**************************************************************************************
Exclusion of Liability for this demo software:
  The following software is intended for and must only be used for reference and in an
  evaluation laboratory environment. It is provided without charge and is subject to
  alterations. There is no warranty for the software, to the extent permitted by
  applicable law. Except when otherwise stated in writing the copyright holders and/or
  other parties provide the software "as is" without warranty of any kind, either
  expressed or implied.
  Please refer to the Agreement in README_DISCLAIMER.txt, provided together with this file!
  By installing or otherwise using the software, you accept the terms of this Agreement.
  If you do not agree to the terms of this Agreement, then do not install or use the
  Software!
**************************************************************************************/

/**************************************************************************************

Copyright (c) Hilscher Gesellschaft fuer Systemautomation mbH. All Rights Reserved.

***************************************************************************************/

#ifndef COMPONENTS_CIFXAPPLICATIONDEMO_INCLUDES_APP_DEMOAPPLICATION_H_
#define COMPONENTS_CIFXAPPLICATIONDEMO_INCLUDES_APP_DEMOAPPLICATION_H_

/*****************************************************************************/
/*! General Inclusion Area                                                   */
/*****************************************************************************/

#include "stdio.h"                  /** Include C standard library input/output header */
#include "string.h"           
#include "stdbool.h"
#include "Hil_Compiler.h"
#include "cifXErrors.h"             /** Include cifX driver API error definition */
#include "cifXUser.h"               /** Include cifX driver API definition       */
#include "hostAbstractionLayer.h"

/*****************************************************************************/
/*! PROCESS DATA                                                             */
/*****************************************************************************/

typedef __HIL_PACKED_PRE struct APP_PROCESS_DATA_INPUT_Ttag /* Consumed data (PLC Output) */
{
  uint8_t start;
  uint8_t commandID;
  float position;
  float duration;
} __HIL_PACKED_POST APP_PROCESS_DATA_INPUT_T;

typedef __HIL_PACKED_PRE struct APP_PROCESS_DATA_OUTPUT_Ttag /* Produced data (PLC Input) */
{
  uint8_t done;
  uint8_t status;
  uint8_t actuation_CH1run;
  uint8_t actuation_CH2run;
  uint8_t actuation_CH1status;
  uint8_t actuation_CH2status;  
} __HIL_PACKED_POST APP_PROCESS_DATA_OUTPUT_T;


/*****************************************************************************/
/*! ACYCLIC DATA                                                             */
/*****************************************************************************/

typedef __HIL_PACKED_PRE struct APP_ACYCLIC_DATA_Ttag
{
  /* Acyclic data of sensors */
  uint8_t  bSensor1_Mode;             /* Is updated whenever is is accesses (bus or terminal) */
  uint16_t usSensor1_StatusCode;      /* Is updated App_IODataHandler()                       */

  uint8_t  bSensor2_Mode;             /* Is updated whenever is is accesses (bus or terminal) */
  uint16_t usSensor2_StatusCode;      /* Is updated App_IODataHandler()                       */

  /* Acyclic data of actuators */
  uint8_t  bActuator1_Mode;           /* Is updated whenever is is accesses (bus or terminal) */
  uint16_t usActuator1_StatusCode;    /* Is updated App_IODataHandler()                       */

  uint8_t  bActuator2_Mode;           /* Is updated whenever is is accesses (bus or terminal) */
  uint16_t usActuator2_StatusCode;    /* Is updated App_IODataHandler()                       */

} __HIL_PACKED_POST APP_ACYCLIC_DATA_T;

/*****************************************************************************/
/*! APPLICATION DEMO RESOURCES                                               */
/*****************************************************************************/

typedef struct APP_DATA_Ttag
{
  CIFX_PACKET               tPacket;          /** Buffer for mailbox packets. Used for sending and receiving.*/
  APP_PROCESS_DATA_INPUT_T  tInputData;       /** Consumed process data. Data that is received from the PLC. */
  APP_PROCESS_DATA_OUTPUT_T tOutputData;      /** Produced process data. Data that is sent to the PLC.       */
  APP_ACYCLIC_DATA_T        tAcyclicData;     /** Application data available via acyclic accesses.           */

  bool                      fRunning;
  bool                      fInputDataValid;

  CIFXHANDLE                hChannel;         /** Handle of netX DPM communication channel                */
  CHANNEL_INFORMATION       tChannelInfo[1];  /** DPM channel information. Read during application start. */
  BOARD_INFORMATION         tBoardInfo;       /** netX Board information. Read during application start.  */

} APP_DATA_T;


/*****************************************************************************/
/*! FUNCTION PROTOTYPES                                                      */
/*****************************************************************************/

void App_IODataHandler(void* ptAppResources);
void App_IO_UpdateCycleCounter(APP_DATA_T* ptAppData);

int  App_CifXApplicationDemo(void);
void App_Selftest(void);
void App_ReadBoardInfo(const CIFXHANDLE hDriver, BOARD_INFORMATION* const ptBoardInfo);
void App_ReadChannelInfo(const CIFXHANDLE hChannel, CHANNEL_INFORMATION* const ptChannelInfo);


extern int32_t Protocol_PacketHandler     (APP_DATA_T* ptAppData);
extern int32_t Protocol_StartConfiguration(APP_DATA_T* ptAppData);

#endif /** COMPONENTS_CIFXAPPLICATIONDEMO_INCLUDES_APP_DEMOAPPLICATION_H_ */

/**************************************************************************************
Exclusion of Liability for this demo software:
  The following software is intended for and must only be used for reference and in an
  evaluation laboratory environment. It is provided without charge and is subject to
  alterations. There is no warranty for the software, to the extent permitted by
  applicable law. Except when otherwise stated in writing the copyright holders and/or
  other parties provide the software "as is" without warranty of any kind, either
  expressed or implied.
  Please refer to the Agreement in README_DISCLAIMER.txt, provided together with this file!
  By installing or otherwise using the software, you accept the terms of this Agreement.
  If you do not agree to the terms of this Agreement, then do not install or use the
  Software!
**************************************************************************************/

/**************************************************************************************

Copyright (c) Hilscher Gesellschaft fuer Systemautomation mbH. All Rights Reserved.

***************************************************************************************/

#ifndef COMPONENTS_CIFXAPPLICATIONDEMO_INCLUDES_APP_PACKETCOMMUNICATION_H_
#define COMPONENTS_CIFXAPPLICATIONDEMO_INCLUDES_APP_PACKETCOMMUNICATION_H_

/*****************************************************************************/
/*! General Inclusion Area                                                   */
/*****************************************************************************/

#include <stdint.h>
#include <stdbool.h>
#include "cifXUser.h"
#include "cifXErrors.h"

/*****************************************************************************/
/*! DEFINITIONS                                                              */
/*****************************************************************************/

#define NEWLINE "\r\n"

/* Possible values for ulSrc field of packet header */
#define SYSTEM_CHANNEL  0x00
#define CHANNEL0        0x01
#define CHANNEL1        0x02
#define CHANNEL2        0x03
#define CHANNEL3        0x04
#define LOCAL_CHANNEL   0x20

/* Timeout values for sending (TX) and receiving (RX) packets. */
#define TX_TIMEOUT       500 /* milliseconds */
#define RX_TIMEOUT        10 /* milliseconds */
#define TXRX_TIMEOUT     500 /* milliseconds */

/*****************************************************************************/
/*! FUNCTION PROTOTYPES                                                      */
/*****************************************************************************/

/*****************************************************************************/
/*! Send a packet via the given channel
 *
*   \param hChannel   [in] Communication channel handle acquired by xChannelOpen
*   \param ptSendPkt  [in] Packet to be sent
*   \param ulTimeout  [in] Time in ms to wait for successful sending.
*/
/*****************************************************************************/
uint32_t Pkt_SendPacket   ( CIFXHANDLE hChannel, CIFX_PACKET* ptSendPkt, uint32_t ulTimeout);


/**************************************************************************************/
/**************************************************************************************/

/*   Synchronous Packet Interface

  This packet interface enables the user to send/receive request/confirmation packets in a synchronous fashion.
  The handling of indication packets is completely separated from that.

  To do so, the user:
    1) Registers his indication callback function using Pkt_RegisterIndicationHandler()
    2) Uses Pkt_SendReceivePacket() for sending/receiving request/confirmation packets
    3) Makes sure the function Pkt_CheckReceiveMailbox() gets called cyclically in order to poll the receive
       mailbox for indication packets.
 */

/****************************************************************************************/
/** This function can be used to register an indication packet handler.
 *  Every time an indication is received, this handler will be called.
 *
 * \param fnHandler   [in]     Callback function that will be called every
 *                             time an indication packet is received.
 *                             Note: fnHandler is supposed to return true, in case the
 *                                   packet was processed. Otherwise, false shall be returned.
 * \param pvUserData  [in]     Parameter that will be provided when calling fnHandler()
 *
 * \return   true, if handler could be registered successfully, false otherwise.
 */
bool     Pkt_RegisterIndicationHandler( bool(*fnHandler)(CIFX_PACKET* ptPacket, void* pvUserData), void* pvUserData );

/****************************************************************************************/
/** This function can be used to transmit a request packet and receive the corresponding
 *  confirmation in a synchronous manner.
 *  After sending the request packet, the function waits for the confirmation packet.
 *
 *  During waiting, also indication packets and other (unexpected) confirmation packets are handled:
 *    - Indication packets are dispatched by using the registered
 *      indication handler (see Pkt_RegisterIndicationHandler).
 *    - Unexpected confirmation packets are put into a queue for later processing.
 *
 * \param hChannel   [in]      Handle to communication channel (acquired by xChannelOpen)
 * \param ptPacket   [in,out]  Pointer to request packet. This resource will also be
 *                             used to provided the confirmation packet content to the caller.
 * \param ulTimeout  [in]      Timeout value in milliseconds that will be used for sending the request and
 *                             receiving the confirmation packet.
 *
 * \return    CIFX_NO_ERROR:    Request packet could be sent/received successfully.
 *         != CIFX_NO_ERROR:    Sending request packet or receiving confirmation packet failed.
 *         Note: this return code is not affected by the packet status of the confirmation packet.
 */
uint32_t Pkt_SendReceivePacket( CIFXHANDLE hChannel, CIFX_PACKET* ptPacket, uint32_t ulTimeout );

/****************************************************************************************/
/** This function can be used to poll for mailbox packets and automatically pass them to the
 *  indication handler (registered via Pkt_RegisterIndicationHandler() ).
 *
 *  Note: All packets not processed by the indication handler
 *        will be returned with status code CIFX_INVALID_COMMAND.
 *
 * \param hChannel   [in]  Handle to communication channel (acquired by xChannelOpen)
 * \param ptPacket   [in]  Pointer to packet resource. This resource will be used to receive a packet
 *                         from the mailbox and pass it to the indication handler.
 *
 * \return    CIFX_NO_ERROR:    Request packet could be sent/received successfully.
 *         != CIFX_NO_ERROR:    Sending request packet or receiving confirmation packet failed.
 *         Note: this return code is not affected by the packet status of the confirmation packet.
 */
uint32_t Pkt_CheckReceiveMailbox( CIFXHANDLE hChannel, CIFX_PACKET* ptPacket );

#endif /* COMPONENTS_CIFXAPPLICATIONDEMO_INCLUDES_APP_PACKETCOMMUNICATION_H_ */

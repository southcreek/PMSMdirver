/*
 * User_Compiler.h
 *
 *  Created on: 31.01.2017
 *      Author: RalfH
 */

#ifndef USER_COMPILER_H_
#define USER_COMPILER_H_

  #define __HIL_PACKED_PRE
  #define __HIL_PACKED_POST

  #define __HIL_ALIGNED_DWORD__

#endif /* USER_COMPILER_H_ */
